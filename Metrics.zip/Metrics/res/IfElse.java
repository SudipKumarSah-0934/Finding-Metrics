public void sample(int a)
{
	a++;
	if(a>0) {
		a++;
	}
	else {
		a--;
	}
	
}

