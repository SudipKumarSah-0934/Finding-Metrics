public void sample(int a)
{
	do {
		a++;
		if(a%5 == 0) {
			break;
		}
	}while(a<100);
	
}

