public void sample(int a)
{
	switch(a) {
	case 1:
		a++;
		break;
	case 2:
		a--;
		break;
	case 3:
		a=0;
		break;
	}
	
}

