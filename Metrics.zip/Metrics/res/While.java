public void sample(int a)
{
	a=0;
	while(a<100) {
		a++;
		if(a%5 == 0) {
			continue;
		}
	}
	
}

