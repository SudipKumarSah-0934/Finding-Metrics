package src.analysis.graph;

public class Arc {
	private int id;
	private int dest;
	private Arc nextArc;
	private String info;
	private String color;
	private String style;

	private static int ID = 0;

	public Arc() {
		this.id = Arc.ID++;
		this.nextArc = null;

		this.info = "";
		this.color = "black";
		this.style = "solid";
	}

	public Arc(int dest) {
		this();
		this.dest = dest;
	}

	public Arc(int dest, Arc nextArc) {
		this(dest);
		this.nextArc = nextArc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public int getDest() {
		return dest;
	}

	public void setDest(int dest) {
		this.dest = dest;
	}

	public Arc getNextArc() {
		return nextArc;
	}

	public void setNextArc(Arc nextArc) {
		this.nextArc = nextArc;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getStyle() {
		return style;
	}

	public void setStyle(String style) {
		this.style = style;
	}

	public void setAttributes(String info, String style, String color) {
		this.setInfo(info);
		this.setStyle(style);
		this.setColor(color);
	}
}