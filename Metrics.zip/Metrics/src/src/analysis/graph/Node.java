package src.analysis.graph;

public class Node {
	private int id;
	private Arc firstArc;
	private String info;
	private String shape;
	private String fillColor;
	private int type;
	private boolean canReach;

	private static int ID = 1;
	public static int SIMPLE_NODE = 0;
	public static int IF_NODE = 1;
	public static int WHILE_NODE = 2;
	public static int ELSE_NODE = 3;
	public static int SWITCH_NODE = 4;

	public Node() {
		this.id = Node.ID++;
		this.info = "Node " + this.id;
		this.shape = "box";
		this.fillColor = "blue";
		this.type = SIMPLE_NODE;
		this.canReach = true;
		firstArc = null;
	}

	public Node(String info) {
		this();
		this.info = info;
	}

	public Node(String info, String shape, String fillColor, int type) {
		this();
		this.info = info;
		this.shape = shape;
		this.fillColor = fillColor;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public Arc getFirstArc() {
		return firstArc;
	}

	public void setFirstArc(Arc firstArc) {
		this.firstArc = firstArc;
	}

	public String getShape() {
		return shape;
	}

	public void setShape(String shape) {
		this.shape = shape;
	}

	public String getFillColor() {
		return fillColor;
	}

	public void setFillColor(String fillColor) {
		this.fillColor = fillColor;
	}

	public void setAttributes(String info, String shape, String fillColor, int type) {
		this.setInfo(info);
		this.setShape(shape);
		this.setFillColor(fillColor);
		this.setType(type);
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public boolean isCanReach() {
		return canReach;
	}

	public void setCanReach(boolean canReach) {
		this.canReach = canReach;
	}
}
