package src.analysis.graph;

import java.util.Stack;

import src.utils.FileHandle;
import src.utils.Structure;

/**
 * 有向图结构：邻接链表
 * 
 * @author naplues
 *
 */
public class Graph {

	private String name;
	private Node[] nodes;
	private int nodeNumber;
	private int arcNumber;
	private static int MAX_NODES_NUM = 2000;
	int IF_TEMP_NO = 1;
	int WHILE_TEMP_ID = 1;
	int DO_WHILE_TEMP_NO = 1;
	int SWITCH_TEMP_NO = 1;
	int RETURN_NO = 1;
	int BREAK_NO = 1;

	Stack<Integer> nodeStack = new Stack<>();
	Stack<String> typeStack = new Stack<>();
	Stack<Integer> breakStack = new Stack<>();
	Stack<Stack<Integer>> allBreakStack = new Stack<>();
	Stack<Integer> continueStack = new Stack<>();
	Stack<Stack<Integer>> allContinueStack = new Stack<>();
	Stack<Integer> switchStack = new Stack<>();
	Stack<Integer> ifStack = new Stack<>();
	Stack<Integer> returnStack = new Stack<>();

	int noBreakSwitchNode = -1;
	boolean entry = false;
	String lastState = "";
	boolean isSwitch = false;
	boolean isIfElse = false;
	int i = 0, j = 0, k = 0;

	public Graph constructGraph(String structure) {
		Graph graph = new Graph();

		nodes[0] = new Node("Start", "Msquare", "green", Node.SIMPLE_NODE);
		nodeNumber++;

		for (; i < structure.length(); i++) {

			if (structure.charAt(i) == 'P') {
				Node newNode = new Node();
				nodeNumber++;
				if (isSwitch) {
					int switchNode = nodeStack.peek();
					Arc arc = new Arc(newNode.getId(), nodes[switchNode - 1].getFirstArc());
					arc.setInfo(Structure.labels.get(k++));
					nodes[switchNode - 1].setFirstArc(arc);
					isSwitch = false;
				} else if (isIfElse) {

					int ifNode = nodeStack.peek();
					Arc arc = new Arc(newNode.getId(), nodes[ifNode - 1].getFirstArc());
					arc.setAttributes("No", "bold", "red");
					nodes[ifNode - 1].setFirstArc(arc);
					isIfElse = false;
				} else {
					Arc arc = new Arc(newNode.getId(), nodes[j].getFirstArc());
					setIfTrueBranchColor(arc);

					if (lastState.equals("do"))
						arc.setAttributes("", "dashed", "blue");

					nodes[j].setFirstArc(arc);
				}

				// structure.charAt(i - 1) == ',' && structure.charAt(i - 2) != 'b'
				if (noBreakSwitchNode != -1) {
					Arc arc = new Arc(newNode.getId(), nodes[noBreakSwitchNode].getFirstArc());
					nodes[noBreakSwitchNode].setFirstArc(arc);
				}
				newNode.setInfo(Structure.labels.get(k++));
				nodes[++j] = newNode;
				lastState = "";
				continue;
			}

			if (structure.charAt(i) == 'r') {
				returnStatment();
				continue;
			}

			if (structure.charAt(i) == 'b') {
				breakStatment();
				continue;
			}

			if (structure.charAt(i) == 'c') {
				continueStatment();
				continue;
			}

			if (structure.charAt(i) == 'D') {
				Node newNode = new Node();
				nodeNumber++;

				if (isSwitch) {
					int switchNode = nodeStack.peek();
					Arc arc = new Arc(newNode.getId(), nodes[switchNode - 1].getFirstArc());
					arc.setInfo(Structure.labels.get(k++));
					nodes[switchNode - 1].setFirstArc(arc);
					isSwitch = false;

				} else if (isIfElse) {
					int ifNode = nodeStack.peek();
					Arc arc = new Arc(newNode.getId(), nodes[ifNode - 1].getFirstArc());
					arc.setAttributes("No", "bold", "red");
					nodes[ifNode - 1].setFirstArc(arc);
					isIfElse = false;
				}
				Arc arc = new Arc(newNode.getId());
				setIfTrueBranchColor(arc);
				nodes[j].setFirstArc(arc);
				nodeStack.push(newNode.getId());

				if (structure.charAt(i + 1) == '0') {
					typeStack.push("if");
					newNode.setAttributes(Structure.labels.get(k++), "diamond", "blue", Node.IF_NODE);
					entry = true;
				} else if (structure.charAt(i + 1) == '1') {
					typeStack.push("else"); // else
					newNode.setAttributes(Structure.labels.get(k++), "diamond", "blue", Node.ELSE_NODE);
					entry = true;
				} else if (structure.charAt(i + 1) == '2') {
					typeStack.push("while");
					newNode.setAttributes(Structure.labels.get(k++), "ellipse", "blue", Node.WHILE_NODE);
					entry = true;
					breakStack = new Stack<>();
					allBreakStack.push(breakStack);
					breakStack = allBreakStack.peek();
					continueStack = new Stack<>();
					allContinueStack.push(continueStack);
					continueStack = allContinueStack.peek();
				} else if (structure.charAt(i + 1) == '3') {
					typeStack.push("do");
					newNode.setInfo(Structure.labels.get(k++));
					breakStack = new Stack<>();
					allBreakStack.push(breakStack);
					breakStack = allBreakStack.peek();
					continueStack = new Stack<>();
					allContinueStack.push(continueStack);
					continueStack = allContinueStack.peek();
				}
				nodes[++j] = newNode;
				continue;
			}

			if (structure.charAt(i) == 'C' && structure.charAt(i + 1) == 'A') {
				startSwitch();
				continue;
			}
			if (structure.charAt(i) == ',') {
				isSwitch = true;
				if (structure.charAt(i - 1) == 'b') {
					switchStack.push(nodes[j].getId());
					noBreakSwitchNode = -1;
				} else {
					noBreakSwitchNode = j;
				}

				continue;
			}

			if (structure.charAt(i) == '|') {
				isIfElse = true;
				ifStack.push(nodes[j].getId());
				continue;
			}

			if (structure.charAt(i) == ')') {
				String type = typeStack.pop();

				if (type.equals("if")) {
					endIf();
					continue;
				}
				if (type.equals("else")) {
					endElse();
					continue;
				}
				if (type.equals("while")) {
					endWhile();
					continue;
				}
				if (type.equals("do")) {
					endDo();
					continue;
				}
				if (type.equals("switch")) {
					endSwitch();
					continue;
				}
			}
		}

		nodes[nodeNumber] = new Node("End", "Msquare", "pink", Node.SIMPLE_NODE);
		Arc arc = new Arc(nodes[nodeNumber].getId(), nodes[nodeNumber - 1].getFirstArc());
		if (lastState.equals("do")) {
			arc.setAttributes("Exit", "dashed", "blue");
		}
		nodes[nodeNumber - 1].setFirstArc(arc);
		nodeNumber++;
		for (; !returnStack.isEmpty();) {
			int returnNode = returnStack.pop();
			arc = new Arc(nodes[nodeNumber - 1].getId());
			arc.setAttributes("Return", "bold", "orange");
			nodes[returnNode - 1].setFirstArc(arc);
		}
		getUnreachableList();
		return graph;
	}

	public void breakStatment() {
		Node newNode = new Node("break" + BREAK_NO++);
		nodeNumber++;

		if (isIfElse) {
			int ifNode = nodeStack.peek();
			Arc arc = new Arc(newNode.getId(), nodes[ifNode - 1].getFirstArc());
			arc.setAttributes("No", "bold", "red");
			nodes[ifNode - 1].setFirstArc(arc);
			isIfElse = false;
		}

		Arc arc = new Arc(newNode.getId());
		setIfTrueBranchColor(arc);
		nodes[j].setFirstArc(arc);
		nodes[++j] = newNode;
		breakStack.push(nodes[j].getId());
		// lastState = "break";
	}

	public void continueStatment() {
		Node newNode = new Node("continue");
		nodeNumber++;

		if (isIfElse) {
			int ifNode = nodeStack.peek();
			Arc arc = new Arc(newNode.getId(), nodes[ifNode - 1].getFirstArc());
			arc.setAttributes("No", "bold", "red");
			nodes[ifNode - 1].setFirstArc(arc);
			isIfElse = false;
		}

		Arc arc = new Arc(newNode.getId());
		setIfTrueBranchColor(arc);
		nodes[j].setFirstArc(arc);
		nodes[++j] = newNode;
		continueStack.push(nodes[j].getId());
		// lastState = "continue";
	}

	public void returnStatment() {
		Node newNode = new Node("return" + RETURN_NO++);
		nodeNumber++;
		Arc arc = new Arc(newNode.getId());
		setIfTrueBranchColor(arc);
		nodes[j].setFirstArc(arc);
		nodes[++j] = newNode;
		returnStack.push(newNode.getId());
		lastState = "return";
	}

	public void endIf() {

		Node newNode = new Node("if-temp" + IF_TEMP_NO++);
		nodeNumber++;
		Arc arc = new Arc(newNode.getId(), nodes[j].getFirstArc());
		if (lastState.equals("do")) {
			arc.setAttributes("", "dashed", "blue");
		}

		nodes[j].setFirstArc(arc);

		int ifNode = nodeStack.pop();
		arc = new Arc(newNode.getId(), nodes[ifNode - 1].getFirstArc());
		arc.setAttributes("No", "bold", "red"); // false
		nodes[ifNode - 1].setFirstArc(arc);

		nodes[++j] = newNode;
		lastState = "if";
	}

	public void endElse() {
		Node newNode = new Node("ifelse-temp" + IF_TEMP_NO++);
		nodeNumber++;

		nodeStack.pop();
		int ifNode = ifStack.pop();

		Arc arc = new Arc(newNode.getId());
		nodes[ifNode - 1].setFirstArc(arc);

		arc = new Arc(newNode.getId(), nodes[j].getFirstArc());
		if (lastState.equals("do")) {
			arc.setAttributes("", "dashed", "blue");
		}
		nodes[j].setFirstArc(arc);

		nodes[++j] = newNode;
		lastState = "else";
	}

	public void endWhile() {
		int whileNode = nodeStack.pop();
		Arc arc = new Arc(whileNode, nodes[j].getFirstArc());
		nodes[j].setFirstArc(arc);

		Node newNode = new Node("while-temp" + WHILE_TEMP_ID++);
		nodeNumber++;
		arc = new Arc(newNode.getId(), nodes[whileNode - 1].getFirstArc());
		arc.setAttributes("exit", "dashed", "blue");
		nodes[whileNode - 1].setFirstArc(arc);

		while (!breakStack.isEmpty()) {
			int breakNode = breakStack.pop();
			if (nodes[breakNode - 1].getType() == Node.SIMPLE_NODE) {
				arc = new Arc(newNode.getId());
			} else {
				arc = new Arc(newNode.getId(), nodes[breakNode - 1].getFirstArc());
			}
			arc.setAttributes("break", "dashed", "blue");
			nodes[breakNode - 1].setFirstArc(arc);
		}
		allBreakStack.pop();
		if (!allBreakStack.isEmpty())
			breakStack = allBreakStack.peek();

		while (!continueStack.isEmpty()) {
			int continueNode = continueStack.pop();
			if (nodes[continueNode - 1].getType() == Node.SIMPLE_NODE) {
				arc = new Arc(whileNode);
			} else {
				arc = new Arc(whileNode, nodes[continueNode - 1].getFirstArc());
			}
			arc.setAttributes("continue", "dashed", "orange");
			nodes[continueNode - 1].setFirstArc(arc);
		}
		allContinueStack.pop();
		if (!allContinueStack.isEmpty())
			continueStack = allContinueStack.peek();

		nodes[++j] = newNode;
		lastState = "while";
	}

	public void endDo() {
		Node newNode = new Node(Structure.labels.get(k++));
		newNode.setShape("ellipse");
		nodeNumber++;
		Arc arc = new Arc(newNode.getId());
		nodes[j].setFirstArc(arc);
		int doNode = nodeStack.pop();
		arc = new Arc(doNode, newNode.getFirstArc());
		arc.setAttributes("Yes", "bold", "green");
		newNode.setFirstArc(arc);
		nodes[++j] = newNode;

		newNode = new Node("do-while-temp" + DO_WHILE_TEMP_NO++);
		nodeNumber++;
		arc = new Arc(newNode.getId(), nodes[j].getFirstArc());
		nodes[j].setFirstArc(arc);
		while (!breakStack.isEmpty()) {
			int breakNode = breakStack.pop();
			if (nodes[breakNode - 1].getType() == Node.SIMPLE_NODE) {
				arc = new Arc(newNode.getId());
			} else {
				arc = new Arc(newNode.getId(), nodes[breakNode - 1].getFirstArc());
			}
			arc.setAttributes("break", "dashed", "blue");
			nodes[breakNode - 1].setFirstArc(arc);
		}
		allBreakStack.pop();
		if (!allBreakStack.isEmpty())
			breakStack = allBreakStack.peek();
		while (!continueStack.isEmpty()) {
			int continueNode = continueStack.pop();
			if (nodes[continueNode - 1].getType() == Node.SIMPLE_NODE) {
				arc = new Arc(doNode);
			} else {
				arc = new Arc(doNode, nodes[continueNode - 1].getFirstArc());
			}
			arc.setAttributes("continue", "dashed", "orange");
			nodes[continueNode - 1].setFirstArc(arc);
		}
		allContinueStack.pop();
		if (!allContinueStack.isEmpty())
			continueStack = allContinueStack.peek();

		nodes[++j] = newNode;
		lastState = "do";
	}

	public void startSwitch() {
		Node newNode = new Node(Structure.labels.get(k++), "octagon", "lightgreen", Node.SWITCH_NODE);
		nodeNumber++;
		if (isIfElse) {
			int ifNode = nodeStack.peek();
			Arc arc = new Arc(newNode.getId(), nodes[ifNode - 1].getFirstArc());
			arc.setAttributes("No", "bold", "red");
			nodes[ifNode - 1].setFirstArc(arc);
			isIfElse = false;
		} else {
			Arc arc = new Arc(newNode.getId());
			setIfTrueBranchColor(arc);
			nodes[j].setFirstArc(arc);
		}
		nodeStack.push(newNode.getId());
		typeStack.push("switch");
		nodes[++j] = newNode;
		isSwitch = true;
	}

	public void endSwitch() {
		Node newNode = new Node("switch-temp" + SWITCH_TEMP_NO++);
		nodeNumber++;
		nodeStack.pop();
		for (; !switchStack.isEmpty();) {
			Arc newArc = new Arc(newNode.getId());
			newArc.setAttributes("break", "dashed", "blue");
			nodes[switchStack.pop() - 1].setFirstArc(newArc);
		}
		Arc newArc = new Arc(newNode.getId());
		newArc.setAttributes("break", "dashed", "blue");
		nodes[j].setFirstArc(newArc);
		nodes[++j] = newNode;
		lastState = "switch";
	}

	public void getUnreachableList() {
		boolean flag = false;
		for (int i = 1; i < nodeNumber; i++) {
			flag = false;
			for (int j = 0; j < nodeNumber; j++) {
				Arc arc = nodes[j].getFirstArc();
				while (arc != null) {
					int dest = arc.getDest();
					if ((dest - 1) == i) {
						flag = true;
						break;
					}
					arc = arc.getNextArc();
				}
			}
			nodes[i].setCanReach(flag);
		}
	}

	public void setIfTrueBranchColor(Arc arc) {
		if (entry) {
			arc.setAttributes("Yes", "bold", "green");
			entry = false;
		}
	}

	public String outputGraph(boolean simple, boolean isHorizontal, String path) {
		String string = "";
		Arc arc = null;
		string += "digraph CFG {\n";
		if (isHorizontal)
			string += "rankdir = LR";
		for (int i = 0; i < nodeNumber; i++) {
			if (!nodes[i].isCanReach())
				continue;
			string += " " + nodes[i].getId() + "  ";
			string += "[";
			string += "shape = " + nodes[i].getShape() + ", ";
			// string += "style = filled, ";
			string += "color = " + nodes[i].getFillColor() + ", ";
			if (simple)
				string += "label = \"" + nodes[i].getId() + "\", ";
			else
				string += "label = \"" + nodes[i].getInfo() + "\", ";

			string += "]\n";
		}
		for (int i = 0; i < nodeNumber; i++) {
			if (!nodes[i].isCanReach())
				continue;
			arc = nodes[i].getFirstArc();
			for (; null != arc; arc = arc.getNextArc()) {
				string += " " + nodes[i].getId() + " ";
				string += " -> ";
				string += " " + nodes[arc.getDest() - 1].getId() + "  ";
				string += "[";
				string += "style = " + arc.getStyle() + ", ";
				string += "label=\"" + arc.getInfo() + "\", ";
				string += "fillcolor = " + arc.getColor() + ", ";
				string += "color = " + arc.getColor() + ", ";
				string += "fontcolor = " + arc.getColor();
				string += "]\n";
			}
			string += "\n";
		}
		string += "}";
		FileHandle.writeStringToFile("out/" + path + ".dot", string);
		System.out.println("\nDOT file created");
		return string;
	}

	public void printByNodes() {
		Arc arc = null;
		for (int i = 0; i < nodeNumber; i++) {
			System.out.println(nodes[i].getId() + ":");
			arc = nodes[i].getFirstArc();
			while (null != arc) {
				System.out.print(arc.getId() + "  ");
				arc = arc.getNextArc();
			}
			System.out.println(nodeNumber);
		}
	}

	public Graph() {
		nodes = new Node[Graph.MAX_NODES_NUM];
		this.setNodeNumber(0);
		this.setArcNumber(0);

	}

	public Graph(String structure) {
		this();
		this.constructGraph(structure);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getNodeNumber() {
		return nodeNumber;
	}

	public void setNodeNumber(int nodeNumber) {
		this.nodeNumber = nodeNumber;
	}

	public int getArcNumber() {
		Arc arc = null;
		for (int i = 0; i < nodeNumber; i++)
			for (arc = nodes[i].getFirstArc(); null != arc; arc = arc.getNextArc())
				arcNumber++;
		return arcNumber;
	}

	public void setArcNumber(int arcNumber) {
		this.arcNumber = arcNumber;
	}
}
