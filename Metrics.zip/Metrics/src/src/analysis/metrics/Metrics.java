package src.analysis.metrics;

import java.io.IOException;

import src.analysis.graph.Graph;
import src.utils.Structure;

public class Metrics {

	public static void outputAllMetrics(String filepath) {
		System.out.print("\n---------------------------------------------");
		System.out.println("Cyclomatic complexity: " + Metrics.getCyclomaticNumber(filepath) + '\n');
		Metrics.getLOC(filepath);
	}

	private static int getLOC(String fileName) {
		try {
			return LinesOfCode.countLOC(fileName);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return 0;
	}

	public static int getCyclomaticNumber(String filepath) {
		String structure = Structure.generateStructure("res/" + filepath + ".java");
		// System.out.println(structure);
		// Structure.printLabels();
		Graph graph = new Graph(structure);
		graph.outputGraph(false, false, filepath);
		int n = graph.getNodeNumber();
		int e = graph.getArcNumber();
		System.out.println("Nodes: " + n);
		System.out.println("Edges: " + e);
		return e - n + 2;

	}
}
