package src.run;

import src.analysis.metrics.Metrics;

public class Main {
	public static void main(String[] args) {
		String filepath = "Test";
		Metrics.outputAllMetrics(filepath);
	}
}